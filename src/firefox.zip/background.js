chrome.webRequest.onBeforeRequest.addListener(
    (details) => {
        const url = new URL(details.url);
        if (url.hostname === "minecraft.fandom.com") {
            url.hostname = "minecraft.wiki";
            return { redirectUrl: url.href };
        }
    },
    {
        urls: ["*://minecraft.fandom.com/*"],
        types: ["main_frame"]
    },
    ["blocking"]
);